﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLokalBD {
    class DataNames {
        private int id;
        private string name;
        private int age;

        /*public DataNames(SqlConnection myConnection) {
            SqlDataReader wyn = null;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = myConnection;
            cmd.CommandText = "SELECT IDENT_CURRENT( 'testBDTable' )";
            id = int.Parse(cmd.ExecuteScalar().ToString());
            id++;
        }*/
        public DataNames() { }
        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public int Age { get => age; set => age = value; }
    }
}
