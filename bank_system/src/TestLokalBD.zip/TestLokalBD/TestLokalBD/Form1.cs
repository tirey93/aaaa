﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestLokalBD {
    public partial class Form1 : Form {
        static SqlConnection myConnection = null;
        BindingList<DataNames> dataNames = new BindingList<DataNames>();
        public Form1() {
            InitializeComponent();
            runDatabase();
            getDataNames();

            BindingSource bs = new BindingSource();
            bs.DataSource = dataNames;
            //dataNames.AddingNew += new AddingNewEventHandler(bindingSource_AddingNew);
            //dataNames.ListChanged += new ListChangedEventHandler(bindingSource_ListChanged);
            dataNamesGV.DataSource = dataNames;
            dataNamesGV.Columns["Id"].Visible = false;
            dataNamesGV.AllowUserToAddRows = true;

        }


        /*private void bindingSource_AddingNew(object sender, AddingNewEventArgs e) {
            e.NewObject = new DataNames(myConnection);
        }*/

        private static void runDatabase() {
            myConnection = new SqlConnection
                ("Server= SA-INFO-23\\SQLEXPRESS; "+
                "Database= TestBD; "+
                "Integrated Security=True;");
            myConnection.Open();
        }
        public void getDataNames() {
            SqlDataReader wyn = null;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = myConnection;
            cmd.CommandText = "select * from testBDTable";
            wyn = cmd.ExecuteReader();
            List<string> result = new List<string>();

            while(wyn.Read()) {
                DataNames row = new DataNames();
                if(!wyn.IsDBNull(0)) {
                    row.Id = wyn.GetInt32(0);
                }
                if(!wyn.IsDBNull(1)) {
                    row.Name = wyn.GetString(1);
                }
                if(!wyn.IsDBNull(2)) {
                    row.Age = wyn.GetInt32(2);
                }
                dataNames.Add(row);
            }
            wyn.Close();

        }

        private void button1_Click(object sender, EventArgs e) {
            foreach(DataNames row in dataNames) {
                MessageBox.Show(row.Id + " " + row.Name + " " + row.Age);
            }
        }

        private void dataNamesGV_CellValueChanged(object sender, DataGridViewCellEventArgs e) {
            SqlDataReader wyn = null;
            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand("update_DBtable", myConnection);
            cmd.Parameters.AddWithValue("@id", dataNames[e.RowIndex].Id);
            if(dataNames[e.RowIndex].Name != null) {
                cmd.Parameters.AddWithValue("@name", dataNames[e.RowIndex].Name);
            }
            cmd.Parameters.AddWithValue("@age", dataNames[e.RowIndex].Age);
            cmd.CommandType = CommandType.StoredProcedure;
            wyn = cmd.ExecuteReader();
            int newId = 0;
            bool isInserted = false;
            if(wyn.Read()) {
                if(!wyn.IsDBNull(0)) {
                    newId = wyn.GetInt32(0);
                }
                if(!wyn.IsDBNull(1)) {
                    isInserted = wyn.GetInt32(1) == 1 ? true : false;
                }
            }
            wyn.Close();
            dataNames[e.RowIndex].Id = newId;
            if(!isInserted) {
                dataNamesGV.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Gray;
            }
            else {
                dataNamesGV.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.White;
            }

            //MessageBox.Show(newId + " " + isInserted);
        }
    }
}
